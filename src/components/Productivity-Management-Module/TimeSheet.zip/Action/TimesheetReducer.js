import {
      GET_MODEOF_PAYEMENT,GET_EXPENSE_TYPE
} from './TimesheetAction';

const defaultState = {
    mode_ofpayment:null,
    expense_type:null
}

export const TimesheeReducer = (state=defaultState, action) => {
    console.log("boobooo",action.payload)
    switch(action.type){
        
        case GET_MODEOF_PAYEMENT:
            console.log("dataaaaaaaaaaaaaaa",action.payload);
            
             return {...state,mode_ofpayment:action.payload.data}  
             case GET_EXPENSE_TYPE:
            console.log("heyyyy",action.payload);
            
             return {...state,expense_type:action.payload.data}    
        default:
            return state;
    }
}