import React from 'react';
import Grid from '@material-ui/core/Grid';
import Dropdownantd from '../../../formcomponent/dropdownantd';
import Calenderbox from '../../../formcomponent/calenderbox';
import EnhancedTable from "../../../table/DynTable";
import tableschema from "./Timemanagementschema.json";
import { Icon, Popconfirm, message } from 'antd';

const text="Are you sure you do want to unsubmit the time sheet?"


class Timesheetmanagement extends React.Component{
    state={
        usertabledata:[],
    }
    componentDidMount(){
     
        this.setState({
          usertabledata:
          [{
          "fieldsArray":[
          {"name":"name","value":"Saranya"},
          {"name":"submitted","value":"Yes"},
          {"name":"date","value":"16 oct 2019"},                
          {"name":"unsubmit","value":<div><Popconfirm placement="top" title={text} onConfirm={this.confirm} okText="Confirm" cancelText="Cancel"><Icon type="reload" /></Popconfirm></div>},
          {"name":"download","value":<div className="timeicon"><span className="text-danger"><Icon type="file-pdf" /></span><span className="text-success ml-2"><Icon type="file-pdf"/></span></div>},        
          ]
          
        },
        {"fieldsArray":[
            {"name":"name","value":"Syed"},
            {"name":"submitted","value":"Yes"},
            {"name":"date","value":"16 oct 2019"},
            {"name":"unsubmit","value":<div><Popconfirm placement="top" title={text} onConfirm={this.confirm} okText="Confirm" cancelText="Cancel"><Icon type="reload" /></Popconfirm></div>},
            {"name":"download","value":<div className="timeicon"><span className="text-danger"><Icon type="file-pdf" /></span><span className="text-success ml-2"><Icon type="file-pdf"/></span></div>},

            ]
          
        },
        {
            "fieldsArray":[
                {"name":"name","value":"Suriya"},
                {"name":"submitted","value":"Yes"},
                {"name":"date","value":"16 oct 2019"},
                {"name":"unsubmit","value":<div><Popconfirm placement="top" title={text} onConfirm={this.confirm} okText="Confirm" cancelText="Cancel"><Icon type="reload" /></Popconfirm></div>},
                {"name":"download","value":<div className="timeicon"><span className="text-danger"><Icon type="file-pdf" /></span><span className="text-success ml-2"><Icon type="file-pdf"/></span></div>},

                ]
          
        },
        {
            "fieldsArray":[
                {"name":"name","value":"Spriya"},
                {"name":"submitted","value":"Yes"},
                {"name":"date","value":"15 oct 2019"},
                {"name":"unsubmit","value":<div><Popconfirm placement="top" title={text} onConfirm={this.confirm} okText="Confirm" cancelText="Cancel"><Icon type="reload" /></Popconfirm></div>},
                {"name":"download","value":<div className="timeicon"><span className="text-danger"><Icon type="file-pdf" /></span><span className="text-success ml-2"><Icon type="file-pdf"/></span></div>},

                ]
          
        },
        {
            "fieldsArray":[
                {"name":"name","value":"Ram"},
                {"name":"submitted","value":"Yes"},
                {"name":"date","value":"15 oct 2019"},
                {"name":"unsubmit","value":<div><Popconfirm placement="top" title={text} onConfirm={this.confirm} okText="Confirm" cancelText="Cancel"><Icon type="reload" /></Popconfirm></div>},
                {"name":"download","value":<div className="timeicon"><span className="text-danger"><Icon type="file-pdf" /></span><span className="text-success ml-2"><Icon type="file-pdf"/></span></div>},

                ]
          
        },
        {
            "fieldsArray":[
                {"name":"name","value":"Manivannan"},
                {"name":"submitted","value":"Yes"},
                {"name":"date","value":"16 oct 2019"},
                {"name":"unsubmit","value":<div><Popconfirm placement="top" title={text} onConfirm={this.confirm} okText="Confirm" cancelText="Cancel"><Icon type="reload" /></Popconfirm></div>},
                {"name":"download","value":<div className="timeicon"><span className="text-danger"><Icon type="file-pdf" /></span><span className="text-success ml-2"><Icon type="file-pdf"/></span></div>},
                ]
          
        },
        {
            "fieldsArray":[
                {"name":"name","value":"Ashwin"},
                {"name":"submitted","value":"Yes"},
                {"name":"date","value":"15 oct 2019"},
                {"name":"unsubmit","value":<div><Popconfirm placement="top" title={text} onConfirm={this.confirm} okText="Confirm" cancelText="Cancel"><Icon type="reload" /></Popconfirm></div>},
                {"name":"download","value":<div className="timeicon"><span className="text-danger"><Icon type="file-pdf" /></span><span className="text-success ml-2"><Icon type="file-pdf"/></span></div>},

                ]          
        },
      ],
        })
          }
          confirm=()=>{
              message.info('Clicked on Confirm');
          }
    render(){
        return(
            <React.Fragment>     
                <div className="card top_move">
                    <div className="card-body">
                        <Grid container spacing={2}>
                            <Grid item md={3} sm={5}>
                                <Dropdownantd
                                className="w-100"
                                option={["xx","yy"]}
                                label="Department"
                                />
                            </Grid>
                            <Grid item md={3} sm={5}>
                                <Dropdownantd
                                className="w-100"
                                option={["xx","yy"]}
                                label="Employee"
                                />
                            </Grid>
                            <Grid item md={3} sm={5}>
                                <Calenderbox
                                className="w-100"
                                label="Date"
                                />
                            </Grid>
                            <Grid item md={3} sm={5}>
                                <Calenderbox
                                className="w-100"
                                label="To"
                                />
                            </Grid>
                        </Grid>
                        <div className="table_x_scroll">
                        <EnhancedTable
                        editData={(data)=>this.editData(data)} 
                        deleteData={(data)=>this.deleteData(data)} 
                        tabledata={this.state.usertabledata} 
                        primaryKey="userId" 
                        tableschema={tableschema.fields} 
                        multideleteData={(data)=>this.multideleteData(data)}
                        editclose={"editicon"}
                        mainclassName={"userwidth"}
                        // tablehead={"Candidateview"}
                        />
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }
}
export default Timesheetmanagement;