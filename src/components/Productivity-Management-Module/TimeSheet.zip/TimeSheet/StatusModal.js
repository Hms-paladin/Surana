import React from 'react';
import './timesheet.css';
import Card from 'react-bootstrap/Card';





class StatusModal extends React.Component{
    state={
        patent:[
          {
            id:1,
            name:'Patent for Jhon ',
            time:'9:30AM-10:30AM'
          },{
            id:2,
            name: 'Original Suit',
            time:'9:30AM-10:30AM'
          },
          {
          id:3,
            name:'Divorce case of Prasanth',
            time:'11:00AM-12:00PM'
          },
          {
            id:4,
              name:'Breakup of Ashwin',
              time:'2:00PM-3:30PM Dec6'
            },
            {
              id:5,
              name:'Mani murder case',
              time:'3:45PM-4:45PM'
            },
            {
              id:6,
              name:'Syed and Arjun disappeared case',
              time:'5:00PM-6:00PM'
            }
        ], 
       
        progress:0
    }
    clickHandler() {
        this.setState({
          progress: this.state.progress < 100 ? this.state.progress + 5 : 100
        });
      }
      clickHandlerMinus() {
        this.setState({
          progress: this.state.progress > 5 ? this.state.progress - 5 : 0
        });
      }
    render(){
        var progress = {
            width: this.state.progress + "%",
            // width: this.state.progress - "%"
        
          }
          
        return(
            <React.Fragment>
                <div className="d-flex">
                <div className="line">
                <h5 className="form-subheading">Status </h5>
                <Card>
                          <Card.Body>
                    <div className="scroll_right">
                 <h5 className="form-subheading">Task List </h5>
                
                {
                    this.state.patent.map((val)=>{
                        return(
                         
                       <div className="d-flex">
                         <div className="w-100 padding_top">
                           <div className="hoverr">
                        <div className="font_patent">
                        {val.name}
                        </div>
                        <span>
                        {val.time}
                        </span>
                        </div>
                        </div>
                        </div>
                       
                    )})
                }
                
                </div>
                </Card.Body >
                        </Card>
              </div>
              <div className="task_width">
                  <h5 style={{marginLeft:'25%'}} className="form-subheading">Task Status</h5>
                  <Card className="card_task">
                  <div className="shell_width">
                  <div className="shell">
                   <div className="bar" style={ progress }>
                   <span>  { this.state.progress + "%" }</span>
                </div>
             </div>
               <div>
               <button onClick={ this.clickHandler.bind(this)  }>+</button>
               <button onClick={ this.clickHandlerMinus.bind(this)  }>-</button>
               </div>
           </div>
           </Card>
              </div>
              </div>
            </React.Fragment>
        )
    }
}
export default StatusModal;