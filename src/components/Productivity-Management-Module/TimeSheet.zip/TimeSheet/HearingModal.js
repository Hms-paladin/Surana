import React from 'react'
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button'
import Grid from '@material-ui/core/Grid';
import Calenderbox from '../../../formcomponent/calenderbox'
import Inputantd from '../../../formcomponent/inputantd';
import Dropdownantd from '../../../formcomponent/dropdownantd';
import Textareaantd from '../../../formcomponent/textareaantd'
import {Radio} from 'antd';
import './HearingModal.css';
import ValidationLibrary from "../../../validationlibrary/validation";
class HearingModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          value:1,
          radioon:false,
          errordummy:true,
          hearingmodaldata:
          {'outcome':
          {'value':'',
          validation:[{'name':'required'},{name:'alphabetsOnly'}],
          error:null,
          errmsg:null
        },
      },
    };
      }
    clickon=(e)=>{
        this.setState({
            radioon:true
        })
    }
    yesClick=(e)=>{
        this.setState({
            radioon:false,
        })
    }
    onChange = e => {
        console.log('radio checked', e.target.value);
        this.setState({
            value: e.target.value,
        });
    }
    checkValidation=()=>{
        var mainvalue={}
        var hearingmodaldata=this.state.hearingmodaldata;
        var hearingmodalkeys=Object.keys(hearingmodaldata);
        console.log(hearingmodalkeys,"hearingmodalkeys");
        for(var i in hearingmodalkeys){
        var errorcheck=ValidationLibrary.checkValidation(hearingmodaldata[hearingmodalkeys[i]].value,hearingmodaldata[hearingmodalkeys[i]].validation);
        console.log(errorcheck,"errorcheck");
        hearingmodaldata[hearingmodalkeys[i]].error=!errorcheck.state;
        hearingmodaldata[hearingmodalkeys[i]].errmsg=errorcheck.msg;
        mainvalue[hearingmodalkeys[i]] =hearingmodaldata[hearingmodalkeys[i]].value
        }
        var filtererr=hearingmodalkeys.filter((obj)=>
          hearingmodaldata[obj].error==true);
        console.log(filtererr.length)
        if(filtererr.length>0){
          this.setState({error:true})
        }else{
          this.setState({error:false})
        }
        this.setState({
          mainvalue,
          hearingmodaldata
        })   
    }
    changeDynamic=(data,key)=>{
        console.log("key",key);   
        console.log("data",data);   
        var hearingmodaldata=this.state.hearingmodaldata;
         var hearingmodalkeys=Object.keys(hearingmodaldata);
           var errorcheck=ValidationLibrary.checkValidation(data,hearingmodaldata[key].validation);
            hearingmodaldata[key].value=data;
            hearingmodaldata[key].error=!errorcheck.state;
            hearingmodaldata[key].errmsg=errorcheck.msg;
            this.setState({hearingmodaldata});
             var filtererr=hearingmodalkeys.filter((obj)=>
            hearingmodaldata[obj].error==true || hearingmodaldata[obj].error==null );
            if(filtererr.length>0){
                this.setState({error:true,
                    errordummy:false})
            }else{
                this.setState({error:false})
            }
      }
    render() {
        return (
            <React.Fragment>
                {/* <Card>
                        <Card.Body> */}
                <Grid item md={4} sm={6}>
                    <h6 className="form-subheading">Add Hearing Details</h6>
                </Grid>
                <Grid spacing={2} style={{ display: 'flex' }} className="mt-5">
                    <Grid item md={3} sm={4}>
                        <p>Client Name: Manivannan</p>
                    </Grid>
                    <Grid item md={3} sm={4}>
                        <p>Project:TCS</p>
                    </Grid>
                    <Grid item md={3} sm={4}>
                        <p>Date:8 June 2020</p>
                    </Grid>
                </Grid>
                <Grid container spacing={2}>
                    <Grid item md={11} sm={5}>
                        <Textareaantd placeholder="Outcome" className="timesheetinput" 
                          changeData={(data)=>this.changeDynamic(data,'outcome')} 
                          value={this.state.hearingmodaldata.outcome.value} 
                          error={this.state.hearingmodaldata.outcome.error} 
                          errmsg={this.state.hearingmodaldata.outcome.errmsg}
                          />
                    </Grid>
                    <Grid item md={7} sm={5}>
                        <Inputantd placeholder="Action Task" className="w-100" />
                    </Grid>
                    <Grid item md={4} sm={4}>
                        <Calenderbox placeholder="Next Hearing date" className="w-100"></Calenderbox>
                    </Grid>
                    <Grid item md={7} sm={6}>
                        <Dropdownantd placeholder="Task Assigned to" className="w-100" />
                    </Grid>
                    <Grid item md={4} sm={4}>
                        <Calenderbox placeholder="Task completion" className="w-100" />
                    </Grid>
                    <Grid item md={12} sm={6}>
                        <h6 className="form-subheading">Adjournment Taken Details</h6>
                    </Grid>
                    <Grid item md={12} sm={6}>
                        <Grid container spacing={3}>
                      <Grid item md={3} sm={6}> 
                      <label style={{width:"100%"}}>
                            Adjournment Taken
                        </label>  
                        <Radio.Group onChange={this.onChange} value={this.state.value} className="mt-1">
                            <Radio value={1} onClick={this.yesClick}>Yes</Radio>
                            <Radio value={2}  onClick ={this.clickon}>No</Radio>
                        </Radio.Group>
                    </Grid>
                <Grid item md={7} sm={6}>
                {this.state.radioon == false ?
                    <Grid container>
                        <Grid item md={5} sm={6}>
                            <Dropdownantd label="Taken Party" className="w-100"/>
                        </Grid>
                        <Grid item md={1} sm={1}/>
                        <Grid item md={5} sm={6}>
                            <Dropdownantd label="Taken By" className="w-100"/>
                        </Grid>
                    </Grid>
                        : null
                }
                </Grid>
                </Grid>
                </Grid>
                        <Grid item md={11} sm={6}>
                            <>
                            {this.state.radioon == false ?
                            <Textareaantd label="Reason" className="w-100"/>
                            : null      
                            }
                            </>
                  </Grid>   
                  </Grid>   
                  <Grid container
                direction="row"
                justify="center"
                alignItems="center" 
                className="mt-2 "
                spacing={3}>
                    <Grid item className="mt-4" >
                    <Button className="btnwidth btnclr" onClick={()=>this.checkValidation()}>Save</Button>
                    </Grid>
                    <Grid item className="mt-4">
                    <Button className="btnwidth btnclr_outline">Cancel</Button>
                    </Grid>
                </Grid>
                {/* </Card.Body>
                    </Card> */}
            </React.Fragment>
        )
    }
}
export default HearingModal;