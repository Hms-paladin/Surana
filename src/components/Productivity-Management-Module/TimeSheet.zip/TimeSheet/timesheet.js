import React from 'react';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card'
import { Input, Modal } from 'antd';
import { Grid } from '@material-ui/core';
import LocalOfferOutlinedIcon from '@material-ui/icons/LocalOfferOutlined';
import PlayArrowIcon from '@material-ui/icons/PlayArrow';
import PauseIcon from '@material-ui/icons/Pause';
import AccessTimeIcon from '@material-ui/icons/AccessTime';
import Fab from '@material-ui/core/Fab';
import Timesheetmodel from "./timesheetmodel";
import { connect } from 'react-redux';
import "./timesheet.css"
import { Select } from 'antd';
import AccessModal from './AccessModal';
import HearingModal from './HearingModal';
import StatusModal from './StatusModal'
import OPEmodal from './OPEmodal'

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import FiberManualRecordIcon from '@material-ui/icons/FiberManualRecord';
import DateRangeIcon from '@material-ui/icons/DateRange';
import PlayArrowOutlinedIcon from '@material-ui/icons/PlayArrowOutlined';
import { IoMdMore } from "react-icons/io";
import Edit from '../../../images/edit.svg';
import Pin from '../../../images/pin.png';
import Pinfilled from '../../../images/pinfill.png';
import Dropdownantd from '../../../formcomponent/dropdownantd'
import Inputantd from '../../../formcomponent/inputantd'
const { Option } = Select;

class Timesheet extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            hours: 0,
            seconds: 0,
            minutes: 0,
            settimeon: false,
            changebtn: true,
            open: false,
            Hearing: false,
            AccessModal: false,
            StatusModal:false,
            // backdrop:true,
            type:'',
            title:'',
            visible:false,
            OPEmodal:false
        }
    }
    callanotherfun = () => {
        if (this.state.seconds < 59) {
            this.setState({ seconds: this.state.seconds + 1 })
        } else if (this.state.minutes < 59) {
            this.setState({
                seconds: 0,
                minutes: this.state.minutes + 1
            })
        } else (
            this.setState({
                seconds: 0,
                minutes: 0,
                hours: this.state.hours + 1
            })
        )
    }
    callroutine = () => {
        this.setState({
            settimeon: true,
            changebtn: false,
        })
    }
    callstop = () => {
        this.setState({
            settimeon: false,
            changebtn: true,
        })
    }
    manualtime = () => {
        this.setState({
            open: true
        })
    }
    modelcl = () => {
        this.setState({
            open: false
        })
    }

    handleOk = e => {
        console.log(e);
        this.setState({
          visible: false,
        });
      };
    
      handleCancel = e => {
        console.log(e);
        this.setState({
          visible: false,
        });
      };



    // viewContentHearing = () => {
    //     this.props.dispatch(modalAction({ edit: true }));
    //     this.setState({ Hearing: true })
    // }
    // viewContentAccess = () => {
    //     this.props.dispatch(modalAction({ edit: true }));
    //     this.setState({ AccessModal: true })
    // }
    // viewContentStatus = () => {
    //     this.props.dispatch(modalAction({ edit: true }));
    //     this.setState({ StatusModal: true })
    // }
    // toggle = () => {
    //     this.setState({

    //     })
    // }
    handleClickOpen=(s,title)=>
    {
      console.log("type",title,s)
      this.setState({
        type:s,
        title
      })
      this.setState({AccessModal:true,StatusModal:true,visible:true,OPEmodal:true})
    
    }

    render() {
        const classes = this.props;
        {
            this.state.settimeon && setTimeout(() => {
                this.callanotherfun()
            }, 1000)
        }
        const { modal, dispatch } = this.props;
        return (
            <div className="Timesheet_Main top_move">
                <div>
                    <div className="card timesheet_assign">
                        <div className="card-body">
                            <Button variant="danger" style={{float:'right'}} onClick={() => this.handleClickOpen("assign_access")}>
                               Assign Access 
                            </Button>
                        </div>
                    </div>
                </div>
            <div>
                <Card className="timesheet_card">
                    <Card.Body>
                        <Card.Text>
                            <Grid container spacing={3} className="timesheet_gridwidth">
                                <Grid item md={3} sm={5}>
                                    <Inputantd label="What have you worked on?" className="timesheetinput w-100" />
                                </Grid>
                                {/* <Grid item md={1}>
                    </Grid> */}
                                {/* <Grid item md={4} sm={8} className="timesheet_gridalign"> */}
                                    {/* <div className="flex mt-2 timesh_br"> */}
                                    <Grid item md={5} sm={6}>
                                        <Grid container>
                                        <Grid md={3} sm={2} className="w-100">
                                            <Dropdownantd label="Project" className=" w-100">
                                            </Dropdownantd>
                                        </Grid>
                                        <Grid md={3} sm={2} className="w-100 ml-1">
                                            <Dropdownantd label="Activity" className=" w-100">
                                            </Dropdownantd>
                                        </Grid>
                                        <Grid item md={5} sm={7}>
                                        <div className="timesheet_btnmain">
                                            <Button variant="danger"  className="ope_btn" onClick={() => this.handleClickOpen("OPE_modal")}>OPE</Button>
                                            <Button variant="primary" onClick={() => this.handleClickOpen("hearing_modal")} className="ope_btn">Hearing</Button>
                                            <Button variant="success" onClick={() => this.handleClickOpen("status_modal")} className="ope_btn">Status</Button>
                                        </div>
                                        </Grid>
                                        </Grid>
                                    </Grid>

                                    {/* </div> */}
                                {/* </Grid> */}
                                <Grid item md={4} sm={7}>
                                    <Grid container spacing={3} className="timesheet_clkalign">
                                <Grid item md={3} sm={3} className="">
                                    <div className="mt-2 flex tmiesh_jus_spabt">
                                        <div className="timesh_br_left" />
                                        <LocalOfferOutlinedIcon className="timesh_font_br mt-1" />
                                        <div className="timesh_br_right" />
                                    </div>
                                </Grid >
                                <Grid md={7} sm={6}>
                                    <div className="flex timesh_jus_spaar">
                                        <div className="flex secs_left">
                                            <p className="timesh_num_ft ">
                                                {this.state.hours < 10 && "0"}{this.state.hours}:
                                                 {this.state.minutes < 10 && "0"}{this.state.minutes}:
                                                  {this.state.seconds < 10 && "0"}{this.state.seconds}
                                            </p>
                                            {this.state.changebtn ?
                                                <Button className="ml-2 mt-3 playbtn" onClick={this.callroutine}>
                                                    <PlayArrowIcon />
                                                </Button>
                                                :
                                                <Button className="ml-2 mt-3 pausebtn" onClick={this.callstop}>
                                                    <PauseIcon />
                                                </Button>
                                            }
                                        </div>
                                        <div>
                                
                                            <AccessTimeIcon
                                                className="timesh_clock_align"
                                                color="primary"
                                                onClick={this.manualtime}
                                            />
                                            {/* </Fab> */}
                                        </div>
                                    </div>
                                </Grid>
                                </Grid>
                                </Grid>
                            </Grid>
                        </Card.Text>
                    </Card.Body>
                </Card>

                <Grid container className="timesheet_headingbg">
                        <Grid item md={6} sm={6}>
                            <h5 className="timesheet_headingdata">Today</h5>
                        </Grid>
                        <Grid item md={6} sm={6}>
                            <img src={Edit} className="timesheet_editimg" />
                        </Grid>
                </Grid>
                <div className="timesheet_tablescroll">
                {/* <Grid container className="timesheet_headingbg">
                        <Grid item md={6} sm={6}>
                            <h5 className="timesheet_headingdata">Today</h5>
                        </Grid>
                        <Grid item md={6} sm={6}>
                            <img src={Edit} className="timesheet_editimg" />
                        </Grid>
                </Grid> */}
                <Table aria-label="simple table">                                        
                    <TableBody>
                        <TableRow >
                        <TableCell align="center" className="timesheet_tabledata_one">
                            <span><img src={Pin} className="timesheet_pinIcon"/></span>
                            Court Proceeding
                        </TableCell>
                        <TableCell align="center" className="timesheet_tabledata_two">
                            <span><FiberManualRecordIcon className="timesheet_linkIcon"/></span>
                            Tata Consultancy Service
                        </TableCell>
                        <TableCell align="center" className="timesheet_tabledata_three">Billable</TableCell>
                        <TableCell align="center"><Button className="timesheet_tabledata_btn">Completed</Button></TableCell>
                        <TableCell align="center" className="timesheet_gridmain">
                           <Grid Container className="timesheet_gridcontainer">
                                <Grid item md={12} sm={12}>
                                    <Grid container spacing={1}>
                                        <Grid item md={6} sm={6} className="timesheet_griddata">
                                            <div>9:30pm - 3:30pm</div>
                                        </Grid>
                                        <Grid item md={2} sm={2} className="timesheet_griddata">
                                            <div><DateRangeIcon/></div>
                                        </Grid>
                                        <Grid item md={2} sm={2} className="timesheet_griddata">
                                            <div>6:00</div>
                                        </Grid>
                                        <Grid item md={1} sm={1}>
                                            <div><PlayArrowOutlinedIcon className="timesheet_griddataplayaicons"/></div>
                                        </Grid>
                                        <Grid item md={1} sm={1}>
                                            <div><IoMdMore className="timesheet_griddatamoreicons"/></div>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </TableCell>
                        </TableRow>
                        <TableRow >
                        <TableCell align="center" className="timesheet_tabledata_one">
                            <span><img src={Pinfilled} className="timesheet_pinIcon"/></span>
                            Advice Clients Concurrency
                        </TableCell>
                        <TableCell align="center" className="timesheet_tabledata_two">
                            <span><FiberManualRecordIcon className="timesheet_linkIcon"/></span>
                            Wipro Limited
                        </TableCell>
                        <TableCell align="center" className="timesheet_tabledata_three">value</TableCell>
                        <TableCell align="center" className="timesheet_tabledata_four">
                            <Button className="timesheet_tabledata_btn">Meeting</Button>
                        </TableCell>
                        <TableCell align="center" className="timesheet_gridmain">
                           <Grid Container className="timesheet_gridcontainer">
                                <Grid item md={12} sm={12}>
                                    <Grid container spacing={1}>
                                        <Grid item md={6} sm={6} className="timesheet_griddata">
                                            <div>12:30pm - 3:30pm</div>
                                        </Grid>
                                        <Grid item md={2} sm={2} className="timesheet_griddata">
                                            <div><DateRangeIcon/></div>
                                        </Grid>
                                        <Grid item md={2} sm={2} className="timesheet_griddata">
                                            <div>3:00</div>
                                        </Grid>
                                        <Grid item md={1} sm={1}>
                                            <div><PlayArrowOutlinedIcon className="timesheet_griddataplayaicons"/></div>
                                        </Grid>
                                        <Grid item md={1} sm={1}>
                                            <div><IoMdMore className="timesheet_griddatamoreicons"/></div>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </TableCell>
                        </TableRow>
                        <TableRow >
                        <TableCell align="center" className="timesheet_tabledata_one">
                            <span><img src={Pin} className="timesheet_pinIcon"/></span>
                            Claim Liability
                        </TableCell>
                        <TableCell align="center" className="timesheet_tabledata_two">
                            <span><FiberManualRecordIcon className="timesheet_linkIcon"/></span>
                            L&T Constructions
                        </TableCell>
                        <TableCell align="center" className="timesheet_tabledata_three">General</TableCell>
                        <TableCell align="center"><Button className="timesheet_tabledata_btn">Requirements</Button></TableCell>
                        <TableCell align="center">
                           <Grid Container className="timesheet_gridcontainer">
                                <Grid item md={12} sm={12}>
                                    <Grid container spacing={1}>
                                        <Grid item md={6} sm={6} className="timesheet_griddata">
                                            <div>1:30pm - 4:00pm</div>
                                        </Grid>
                                        <Grid item md={2} sm={2} className="timesheet_griddata">
                                            <div><DateRangeIcon/></div>
                                        </Grid>
                                        <Grid item md={2} sm={2} className="timesheet_griddata">
                                            <div>2:30</div>
                                        </Grid>
                                        <Grid item md={1} sm={1}>
                                            <div><PlayArrowOutlinedIcon className="timesheet_griddataplayaicons"/></div>
                                        </Grid>
                                        <Grid item md={1} sm={1}>
                                            <div><IoMdMore className="timesheet_griddatamoreicons"/></div>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </TableCell>
                        </TableRow>
                    </TableBody>
                </Table>
                </div>

                <Timesheetmodel openmodel={this.state.open}
                    modelcl={() => this.modelcl()}
                />
                {/* {
                    this.state.AccessModal &&
                    <AccessViewContent name={"edit"} modalFooter btnName="Ok" toggle  isOpen={modal.edit} dispatch={dispatch} title={"Assign Access"} backdrop={this.handleBackDrop} modalClassName={"modal-md"} className={"mt-4"} toggle={this.toggle} modalHeader />
                }
                {
                    this.state.Hearing &&
                    <HearingViewContent name={"edit"} modalFooter btnName="Ok" toggle isOpen={modal.edit} dispatch={dispatch} title={"Add Hearing Details"} backdrop={this.state.backdrop} modalClassName={"modal-md"} className={"mt-4"} modalHeader />
                }
                {
                    this.state.StatusModal=="Sa" &&
                    <StatusViewContent name={"edit"} modalFooter btnName="Ok" toggle isOpen={modal.edit} dispatch={dispatch} title={"Status"} backdrop={this.state.backdrop} modalClassName={"modal-md"} className={"mt-4"} modalHeader />
                } */}
                {/* <modalWrapper */}
             {/* isOpen={modal.edit} name={"edit"} title={this.state.title} modalFooter btnName="Ok" toggle dispatch={dispatch} closemodal={this.closemodal} backdrop modalClassName={"modal-md"} className={"mt-4"} modalHeader> */}
             <Modal 
             {...this.props}
              visible={this.state.visible}
             onOk={this.handleOk}
             onCancel={this.handleCancel}
                 footer={null}>
                 {this.state.type === "assign_access" && <AccessModal className="specific_modal"/> || this.state.type=== "hearing_modal" && <HearingModal /> || this.state.type === "status_modal" && <StatusModal/> ||this.state.type ==="OPE_modal" && <OPEmodal/> }
                     
               </Modal>
            </div>
        </div>
        )
    }
}

const mapStateToProps = (state) => ({
    modal: state.modal
});
export default connect(mapStateToProps)(Timesheet);