import { Modal, Button } from 'antd';
import React from 'react';
import { TimePicker } from 'antd';
import moment from 'moment';
import Calenderbox from "../../../formcomponent/calenderbox";

const format = 'HH:mm';

class Timesheetmodel extends React.Component {

  render() {
        var date=new Date()
      const hour=date.getHours()
      const min=date.getMinutes()
      const time=hour+":"+min
      const  day=date.getDate()
      const  month=date.getMonth()
      const  year=date.getFullYear()
      const fulldate=day+":"+month+":"+year
    return (
      <div>
        <Modal
          title="Manual Time"
          visible={this.props.openmodel}
          onOk={this.props.modelcl}
          onCancel={this.props.modelcl}
        >
            <div className="flex">
            Start Time:<br />
         <TimePicker defaultValue={moment(time, format)} format={format} className="timepickerantd mr-3" />
            <br />End Time:<br />
         <TimePicker defaultValue={moment(time, format)} format={format} className="timepickerantd"/>
         </div>
         

         <Calenderbox 
         defaultValue={fulldate} 
         format={'DD/MM/YYYY'} 
         formatdefaultValue={'DD/MM/YYYY'} 
         label="Select Date:"
         />
        </Modal>
      </div>
    );
  }
}

export default Timesheetmodel;
