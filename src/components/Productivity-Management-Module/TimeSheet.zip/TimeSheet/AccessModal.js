import React from 'react'
import {Modal,Tag} from 'antd'
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button'


class AccessModal extends  React.Component{
   state={
     tagname:[{
       tag:'rajesh'
     }]
   }
    render(){
        return(
            <React.Fragment>
                    <h5>Employee</h5>
                    <Card>
                        <Card.Body>
                            {this.state.tagname.map((val,Index)=>{
                                return(
                                    <div>
                                   <Tag  closable onClose={this.log}>
                                    {val.tag}
                                    </Tag>
                                    </div>
                                )
                            })}
                          
                        </Card.Body>
                    </Card>
                    
                







            </React.Fragment>
        )
    }
}
export default AccessModal;