import React from 'react';
import CenteredTabs from "../../../tabcomponent/tabs";
import Timesheetmanagement from './Timesheetmanagement';
import Timesheet from './timesheet';

class TimesheetTab  extends React.Component{
    render(){
        return(
            <React.Fragment>
                <CenteredTabs 
                    tabonelabel="Timesheet"
                    tabtwolabel="Timesheet View"
                  
                    componentone=  {<Timesheet/>}
                    componenttwo={<Timesheetmanagement/>}
               />

        </React.Fragment>
        )
    }
}
export default TimesheetTab;