import React from 'react';
import CenteredTabs from '../../../tabcomponent/tabs';
import Dayreportlist from './Dayreportlist';
import Dayreport from './Dayreport';

class AddDayreport extends React.Component{
    render(){
        return(
            <CenteredTabs
                tabonelabel="List"
                tabtwolabel="Day Report"
                componentone={<Dayreportlist />}
                componenttwo={<Dayreport />}
            />
        )
    }
}

export default AddDayreport;