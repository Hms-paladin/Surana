import React from 'react';
import { Grid } from '@material-ui/core';
import Dropdownantd from '../../../formcomponent/dropdownantd';
import Inputantd from '../../../formcomponent/inputantd';
import ValidationLibrary from "../../../validationlibrary/validation.js"
import Button from 'react-bootstrap/Button';

class Dayreport extends React.Component{
    constructor(props) {
        super(props);
      
        this.state = {
          errordummy:true,
          dayreportdata:
          {'client_name':
          {'value':'',
          validation:[{'name':'required'},{name:'alphabetsOnly'}],
          error:null,
          errmsg:null
        },
        'case_no':
          {'value':'',
          validation:[{'name':'required'},{name:'alphabetsOnly'}],
          error:null,
          errmsg:null
        },
        'court_no':
          {'value':'',
          validation:[{'name':'required'},{name:'alphabetsOnly'}],
          error:null,
          errmsg:null
        },
        'attorney':
          {'value':'',
          validation:[{'name':'required'},{name:'alphabetsOnly'}],
          error:null,
          errmsg:null
        },
      },
    };
      }
    
        
    
    checkValidation=()=>{
        var mainvalue={}
        var dayreportdata=this.state.dayreportdata;
        var targetkeys=Object.keys(dayreportdata);
        console.log(targetkeys,"targetkeys");
        for(var i in targetkeys){
        var errorcheck=ValidationLibrary.checkValidation(dayreportdata[targetkeys[i]].value,dayreportdata[targetkeys[i]].validation);
        console.log(errorcheck,"errorcheck");
        dayreportdata[targetkeys[i]].error=!errorcheck.state;
        dayreportdata[targetkeys[i]].errmsg=errorcheck.msg;
        mainvalue[targetkeys[i]] =dayreportdata[targetkeys[i]].value
        }
        var filtererr=targetkeys.filter((obj)=>
          dayreportdata[obj].error==true);
        console.log(filtererr.length)
        if(filtererr.length>0){
          this.setState({error:true})
        }else{
          this.setState({error:false})
    
        }
        this.setState({
          mainvalue,
          dayreportdata
        })   
    }
    changeDynamic=(data,key)=>{
        console.log("key",key);   
        console.log("data",data);   
        var dayreportdata=this.state.dayreportdata;
         var targetkeys=Object.keys(dayreportdata);
         
           var errorcheck=ValidationLibrary.checkValidation(data,dayreportdata[key].validation);
            dayreportdata[key].value=data;
            dayreportdata[key].error=!errorcheck.state;
            dayreportdata[key].errmsg=errorcheck.msg;
            this.setState({dayreportdata});
             var filtererr=targetkeys.filter((obj)=>
            dayreportdata[obj].error==true || dayreportdata[obj].error==null );
            if(filtererr.length>0){
                this.setState({error:true,
                    errordummy:false})
            }else{
                this.setState({error:false})
            }
      }
    
    
    render(){
        console.log(this.state.mainvalue,"state")
        return(
            <React.Fragment>
                <div className="  card card-min-height top_move">
                <div className="card-body ">
                <Grid container spacing={3}>
                        <Grid item md={3} sm={5} className="w-100">
                            <Inputantd label="Client Name" className="w-100"
                             changeData={(data)=>this.changeDynamic(data,'client_name')} 
                             value={this.state.dayreportdata.client_name.value} 
                             error={this.state.dayreportdata.client_name.error} 
                             errmsg={this.state.dayreportdata.client_name.errmsg} />
                        </Grid>
                        <Grid md={1}/>
                        <Grid item md={3} sm={5}>
                            <Dropdownantd label={"Internal Case No"} className={"w-100"} option={[10,12,13]}
                             changeData={(data)=>this.changeDynamic(data,'case_no')} 
                             value={this.state.dayreportdata.case_no.value} 
                             error={this.state.dayreportdata.case_no.error} 
                             errmsg={this.state.dayreportdata.case_no.errmsg}/>
                        </Grid>
                        <Grid md={1}/>
                        <Grid item md={3} sm={5}>
                            <Dropdownantd label={"Court Case No"} className={"w-100"} option={[110,111,112]}
                             changeData={(data)=>this.changeDynamic(data,'court_no')} 
                             value={this.state.dayreportdata.court_no.value} 
                             error={this.state.dayreportdata.court_no.error} 
                             errmsg={this.state.dayreportdata.court_no.errmsg}/>
                        </Grid>
                        <Grid item md={3} sm={5} className="w-100">
                            <Inputantd label="DRA" className="w-100" />
                            <span className="hint_font">(Auto Generate)</span>
                        </Grid>
                        <Grid md={1}/>
                        <Grid item md={3} sm={5}>
                            <Dropdownantd label={"Attorney"} className={"w-100"} option={["XX","YY"]}
                             changeData={(data)=>this.changeDynamic(data,'attorney')} 
                             value={this.state.dayreportdata.attorney.value} 
                             error={this.state.dayreportdata.attorney.error} 
                             errmsg={this.state.dayreportdata.attorney.errmsg}/>
                        </Grid>
                        <Grid container
                        direction="row"
                        justify="center"
                        alignItems="center" 
                        className="gridbtnalign"
                         spacing={3}>
                        <Grid item >

                        <Button size="lg" className="btnmargin btnwidth btnclr"  onClick={()=>this.checkValidation()}>Save</Button>
                     </Grid>
                       <Grid item >
                            <Button size="lg" className="btnwidth btnclr_outline">Cancel</Button>
                    </Grid>
               </Grid>
                </Grid>
                </div>
                </div>
            </React.Fragment>
        )
    }
}
export default Dayreport;