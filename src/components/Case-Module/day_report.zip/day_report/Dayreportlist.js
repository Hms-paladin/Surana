import React from "react";
import DayreportSchema from "./DayreportSchema.json";
import EnhancedTable from "../../../table/DynTable";


class Dayreportlist extends React.Component{

    constructor(props) {
        super(props);
      
        this.state = {
          userdata:null,
          edituserdata:null,
          modalvisible:false,
          usertabledata:[],
          edit:null,
          modalShow:false,
          modalShowsms:false
        };
      }

      setModalShow=(e)=>{
        this.setState({
            modalShow:e
        })
    }

    setModalShowsms=(e)=>{
      this.setState({
        modalShowsms:e
      })
  }

   

    deleteData=(e)=>{
        this.state.usertabledata.splice(e.sno-1,1)
        var i
        for (i = 0; i < this.state.usertabledata.length; i++){
          this.state.usertabledata[i].sno=i+1
        }
        this.setState({usertabledata:this.state.usertabledata})
      }

      multideleteData=(e)=>{
        let storearr=e
        let sortvalue=storearr.sort(function(a, b){
          return a - b;
      });
        console.log(sortvalue)
        
        let i=1
        for(i=1;i<storearr.length+1;i++){
          this.state.usertabledata.splice(sortvalue[storearr.length-i]-1,1)
        }
    
        let j
        for (j = 0; j < this.state.usertabledata.length; j++){
          this.state.usertabledata[j].sno=j+1
        }
    
        this.setState({
          selected:[],
          usertabledata:this.state.usertabledata
        })
      }

  componentDidMount(){
     
    this.setState({
      usertabledata:
      [{
      "fieldsArray":[
      {"name":"clientname","value":"Saranya"},
      {"name":"courtcaseno","value":"CR1422/19"},
      {"name":"dra","value":"Ranjith"},
      {"name":"ddra","value":"Priya"},
      {"name":"councelassigned","value":"-"},
      {"name":"mas_employee_empFirstName","value":"Sibin Antony"},
      // {"name":'sms',"value":this.sendsms({id:1})},
      // {"name":'email',"value":this.sendemail({id:1})}]
      ]
    },
    {
      "fieldsArray":[
      {"name":"clientname","value":"Suriya"},
      {"name":"courtcaseno","value":"CR1211/19"},
      {"name":"dra","value":"Syed"},
      {"name":"ddra","value":"Mani"},
      {"name":"councelassigned","value":"-"},
      {"name":"designation","value":"developer"},
      {"name":"mas_employee_empFirstName","value":"Sibin Antony"},
      // {"name":'sms',"value":this.sendsms({id:1})},
      // {"name":'email',"value":this.sendemail({id:1})}]
      ]
    },
    {
      "fieldsArray":[
      {"name":"clientname","value":"Divya"},
      {"name":"courtcaseno","value":"CR1234/19"},
      {"name":"dra","value":"Kavya"},
      {"name":"ddra","value":"Ranjith"},
      {"name":"councelassigned","value":"-"},
      {"name":"mas_employee_empFirstName","value":"Sibin Antony"},
      // {"name":'sms',"value":this.sendsms({id:1})},
      // {"name":'email',"value":this.sendemail({id:1})}]
      ]
    },
    {
      "fieldsArray":[
      {"name":"clientname","value":"Priya"},
      {"name":"courtcaseno","value":"CR1233/19"},
      {"name":"dra","value":"Jay"},
      {"name":"ddra","value":"Raj"},
      {"name":"councelassigned","value":"-"},
      {"name":"mas_employee_empFirstName","value":"Sibin Antony"},
      // {"name":'sms',"value":this.sendsms({id:1})},
      // {"name":'email',"value":this.sendemail({id:1})}]
      ]
    },
    {
      "fieldsArray":[
      {"name":"clientname","value":"Esther"},
      {"name":"courtcaseno","value":"CR1433/19"},
      {"name":"dra","value":"Vinay"},
      {"name":"ddra","value":"Arjun"},
      {"name":"councelassigned","value":"-"},
      {"name":"mas_employee_empFirstName","value":"Sibin Antony"},
      // {"name":'sms',"value":this.sendsms({id:1})},
      // {"name":'email',"value":this.sendemail({id:1})}]
      ]
    },
    {
      "fieldsArray":[
      {"name":"clientname","value":"Rasika"},
      {"name":"courtcaseno","value":"CR1455/19"},
      {"name":"dra","value":"Reena"},
      {"name":"ddra","value":"Hema"},
      {"name":"councelassigned","value":"-"},
      {"name":"mas_employee_empFirstName","value":"Sibin Antony"},
      // {"name":'sms',"value":this.sendsms({id:1})},
      // {"name":'email',"value":this.sendemail({id:1})}]
      ]
    },
    {
      "fieldsArray":[
      {"name":"clientname","value":"Swetha"},
      {"name":"courtcaseno","value":"CR1326/19"},
      {"name":"dra","value":"Deepa"},
      {"name":"ddra","value":"Ashwin"},
      {"name":"councelassigned","value":"-"},
      {"name":"mas_employee_empFirstName","value":"Sibin Antony"},
      // {"name":'sms',"value":this.sendsms({id:1})},
      // {"name":'email',"value":this.sendemail({id:1})}]
      ]
    },
  ],
    })
      }

    render(){
        return(
            <div>

<div className="table_x_scroll">
          <EnhancedTable 
          editData={(data)=>this.editData(data)} 
          deleteData={(data)=>this.deleteData(data)} 
          tabledata={this.state.usertabledata} 
          primaryKey="userId" 
          tableschema={DayreportSchema.fields} 
          multideleteData={(data)=>this.multideleteData(data)}
          editclose={"editicon"}
          mainclassName={"userwidth"}
          tablehead={"Day Report View"}
          />

			</div>
                
            </div>
        )
    }
}

export default Dayreportlist;